import os
from datetime import timedelta

basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'you-will-never-guess'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'techinsightsnew.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = True
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 465
    MAIL_USE_SSL = True
    MAIL_USE_TLS = False
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME') or 'app.traveltribe@gmail.com'
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD') or 'rtehxaoanbyvnbqq'  # Use the App Password generated from Google
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER') or 'app.traveltribe@gmail.com'
    SECURITY_PASSWORD_SALT = os.environ.get('SECURITY_PASSWORD_SALT') or 'you-will-never-guess'

    # Configure session lifetime
    PERMANENT_SESSION_LIFETIME = timedelta(days=30)
    
    # Configure Flask-Login remember cookie duration
    REMEMBER_COOKIE_DURATION = timedelta(days=30)
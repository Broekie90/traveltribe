from itsdangerous import URLSafeTimedSerializer as Serializer
from flask import current_app
from app import mail
from flask_mail import Message

def generate_confirmation_token(email):
    serializer = Serializer(current_app.config['SECRET_KEY'])
    return serializer.dumps(email, salt=current_app.config['SECURITY_PASSWORD_SALT'])

def confirm_token(token, expiration=3600):
    serializer = Serializer(current_app.config['SECRET_KEY'])
    try:
        email = serializer.loads(token, salt=current_app.config['SECURITY_PASSWORD_SALT'], max_age=expiration)
    except:
        return False
    return email

def send_otp_email(email, otp):
    msg = Message('Your One-Time Password', sender=current_app.config['MAIL_DEFAULT_SENDER'], recipients=[email])
    msg.body = f'Your one-time password is {otp}. It is valid for 5 minutes.'
    mail.send(msg)


from . import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from datetime import datetime, timedelta
import random
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, DateField
from wtforms.validators import DataRequired
from wtforms.validators import Optional
from sqlalchemy.types import Time


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    email_confirmed = db.Column(db.Boolean, default=False)

    # New fields for OTP
    otp = db.Column(db.String(6), nullable=True)
    otp_generated_at = db.Column(db.DateTime, nullable=True)

    def get_accepted_buddies(self):
        # Get the list of accepted buddies for the current user
        return User.query.join(UserBuddy, UserBuddy.buddy_id == User.id)\
                          .filter(UserBuddy.user_id == self.id, UserBuddy.accepted == True).all()


    def set_password(self, password):
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def generate_otp(self):
        """Generates a new OTP and sets the generation time."""
        otp = str(random.randint(100000, 999999))  # Generate a random 6-digit OTP
        self.otp = otp
        self.otp_generated_at = datetime.utcnow()
        db.session.commit()
        return otp

    def verify_otp(self, otp):
        """Verifies if the provided OTP matches the stored OTP and is within the valid timeframe."""
        if self.otp == otp:
            valid_time = datetime.utcnow() - self.otp_generated_at <= timedelta(minutes=5)
            if valid_time:
                return True
        return False

    def clear_otp(self):
        """Clears the OTP fields after successful verification."""
        self.otp = None
        self.otp_generated_at = None
        db.session.commit()


# Association table for many-to-many relationship
trip_users = db.Table(
    'trip_users',
    db.Column('trip_id', db.Integer, db.ForeignKey('trip.id'), primary_key=True),
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True)
)



class UserBuddy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    buddy_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    accepted = db.Column(db.Boolean, default=False)  # False = pending, True = accepted

    # Relationship for easier querying
    user = db.relationship('User', foreign_keys=[user_id], backref='sent_invitations')
    buddy = db.relationship('User', foreign_keys=[buddy_id], backref='received_invitations')

class Trip(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    start_location = db.Column(db.String(255), nullable=False)
    end_location = db.Column(db.String(255), nullable=False)
    start_date = db.Column(db.Date, nullable=True)  # Allow NULL
    end_date = db.Column(db.Date, nullable=True)  # Allow NULL
    num_days = db.Column(db.Integer, nullable=True)  # Allow NULL

    # Add the relationship to hotels with cascading delete
    hotels = db.relationship(
        'Hotel', 
        back_populates='trip', 
        cascade="all, delete-orphan", 
        lazy='dynamic'
    )

    # Many-to-many relationship with User
    users = db.relationship(
        'User',
        secondary='trip_users',
        backref=db.backref('trips', lazy='dynamic'),
        lazy='dynamic'
    )

    # Add the relationship to activities with cascading delete
    activities = db.relationship(
        'TripActivity', 
        cascade="all, delete-orphan", 
        backref='trip', 
        lazy='dynamic'
    )

    # Relationship to expenses with cascading delete
    expenses = db.relationship(
        'Expense',
        back_populates='trip',
        cascade='all, delete-orphan',  # Correct position for cascading delete
        lazy='dynamic'
    )

    # Add the relationship to trip_blogs with cascading delete
    blogs = db.relationship(
        'TripBlog',  # Assuming the model is called TripBlog
        back_populates='trip',
        cascade='all, delete-orphan',  # This ensures that deleting a trip will delete related blogs
        lazy='dynamic'
    )



class TripActivity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    trip_id = db.Column(
        db.Integer, 
        db.ForeignKey('trip.id', ondelete='CASCADE'), 
        nullable=False
    )
    day = db.Column(db.Integer, nullable=False)
    description = db.Column(db.String(500), nullable=False)
    fromLocation = db.Column(db.String(255), nullable=True) 
    location = db.Column(db.String(255), nullable=True)
    type = db.Column(db.String(50), default="Chilling")  # New field
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    creator = db.relationship('User', backref='activities_created')


class Hotel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    trip_id = db.Column(
        db.Integer, 
        db.ForeignKey('trip.id', ondelete='CASCADE'), 
        nullable=False
    )
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(255), nullable=False)
    from_day = db.Column(db.Integer, nullable=False)  # Start day for the hotel
    to_day = db.Column(db.Integer, nullable=False)    # End day for the hotel

    trip = db.relationship('Trip', back_populates='hotels')

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    trip_id = db.Column(db.Integer, db.ForeignKey('trip.id'), nullable=False)
    date = db.Column(db.Date, default=datetime.utcnow, nullable=False)

    user = db.relationship('User', backref=db.backref('expenses', lazy=True))
    trip = db.relationship('Trip', back_populates='expenses')  # Removed single_parent=True

class TripBlog(db.Model):
    __tablename__ = 'trip_blogs'

    id = db.Column(db.Integer, primary_key=True)
    trip_id = db.Column(db.Integer, db.ForeignKey('trip.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    day = db.Column(db.Integer, nullable=False)  # Day of the trip
    blog_content = db.Column(db.Text, nullable=False)

    trip = db.relationship('Trip', backref=db.backref('blogs', lazy=True))
    user = db.relationship('User', backref=db.backref('blogs', lazy=True))
    # Relationship back to Trip
    trip = db.relationship('Trip', back_populates='blogs')

    def __repr__(self):
        return f'<TripBlog {self.user.username} - Day {self.day}>'

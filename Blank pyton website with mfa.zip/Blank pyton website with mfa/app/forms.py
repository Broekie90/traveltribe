from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, SelectMultipleField, BooleanField, SelectField, DecimalField, HiddenField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError, Length
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, DateField
from wtforms.validators import DataRequired
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, DateField
from wtforms.validators import DataRequired, Optional
from wtforms.fields import SelectMultipleField
from wtforms.widgets import html_params, CheckboxInput
from wtforms import StringField, IntegerField, TimeField, SubmitField


class OTPForm(FlaskForm):
    otp = StringField('One-Time Password', validators=[DataRequired(), Length(min=6, max=6)])
    submit = SubmitField('Verify')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')  # Add this field
    submit = SubmitField('Login')


class TripForm(FlaskForm):
    trip_name = StringField('Trip Name', validators=[DataRequired()])
    start_location = StringField('Start Location', validators=[DataRequired()])
    end_location = StringField('End Location', validators=[DataRequired()])
    start_date = DateField('Start Date', validators=[DataRequired()])  # Allow NULL
    end_date = DateField('End Date', validators=[DataRequired()])  # Allow NULL
    num_days = IntegerField('Number of Days', validators=[Optional()])  # Allow NULL
    selected_users = SelectMultipleField(
        'Assign Users (Optional)',
        choices=[],  # Dynamically populated
        validators=[Optional()],
    )

class ActivityForm(FlaskForm):
    activity = StringField('Activity Description', validators=[DataRequired()])
    day = IntegerField('Day', validators=[DataRequired()])
    time = TimeField('Time', format='%H:%M', validators=[Optional()])  # Use Optional validator
    submit = SubmitField('Add Activity')

class ExpenseForm(FlaskForm):
    description = StringField('Description', validators=[DataRequired()])
    amount = DecimalField('Amount', validators=[DataRequired()])
    user_id = HiddenField('User ID', validators=[DataRequired()])
    user_display = StringField('User', render_kw={"readonly": True})  # No need for `validators=[DataRequired()]`

class BlogForm(FlaskForm):
    blog_content = TextAreaField('Blog Content')  # No validation required
    submit = SubmitField('Submit')

from flask import render_template, session, request, redirect, url_for, flash, current_app as app
from flask_login import login_user, logout_user, current_user, login_required
from . import db, login_manager
from .models import User, Trip, TripActivity, Hotel, Expense, UserBuddy, trip_users, TripBlog
from .forms import RegistrationForm, LoginForm
from sqlalchemy import or_
from flask_wtf import FlaskForm
from io import BytesIO
from flask import send_file
from .utils import generate_confirmation_token, confirm_token
from flask_mail import Message
from . import db, mail
from functools import wraps
from collections import defaultdict
from flask import jsonify
from .utils import send_otp_email
from .forms import LoginForm, OTPForm, TripForm, ActivityForm, ExpenseForm, BlogForm
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, DateField
from wtforms.validators import DataRequired
from flask import render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from app.forms import TripForm  # Import the form
from datetime import datetime, timedelta
from wtforms.validators import DataRequired
from collections import defaultdict

class DummyForm(FlaskForm):
    pass

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def send_confirmation_email(user_email):
    token = generate_confirmation_token(user_email)
    confirm_url = url_for('confirm_email', token=token, _external=True)
    html = render_template('activate.html', confirm_url=confirm_url)
    subject = "Please confirm your email"
    msg = Message(subject, recipients=[user_email], html=html)
    mail.send(msg)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            user = User(username=form.username.data, email=form.email.data)
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            send_confirmation_email(user.email)
            flash('A confirmation email has been sent to you via email.', 'success')
            return redirect(url_for('login'))
        else:
            # Log errors to help debug why the form isn't validating
            for field, errors in form.errors.items():
                for error in errors:
                    print(f"Error in {field}: {error}")
            flash('There was an error with your submission. Please check your details and try again.', 'danger')
    return render_template('register.html', form=form)



@app.route('/confirm/<token>')
def confirm_email(token):
    try:
        email = confirm_token(token)
    except:
        flash('The confirmation link is invalid or has expired.', 'danger')
    user = User.query.filter_by(email=email).first_or_404()
    if user.email_confirmed:
        flash('Account already confirmed. Please login.', 'success')
    else:
        user.email_confirmed = True
        db.session.add(user)
        db.session.commit()
        flash('You have confirmed your account. Thanks!', 'success')
    return redirect(url_for('login'))

def email_confirmed_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.is_anonymous or not current_user.email_confirmed:
            return redirect(url_for('unconfirmed'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/unconfirmed')
def unconfirmed():
    if current_user.is_anonymous or current_user.email_confirmed:
        return redirect(url_for('index'))
    return render_template('unconfirmed.html')


@app.route('/', methods=['GET'])
@login_required
def index():
    form = TripForm()

    # Fetch all trips where the current user is part of the trip
    trips = Trip.query.join(
        trip_users
    ).filter(
        trip_users.c.user_id == current_user.id
    ).order_by(
        Trip.start_date.asc()  # Order by start_date in ascending order
    ).all()

    # Fetch all pending invitations for the current user
    invitations = UserBuddy.query.filter_by(buddy_id=current_user.id, accepted=False).all()

    # Fetch accepted buddies from both user_id and buddy_id
    accepted_buddies = UserBuddy.query.filter(
        (UserBuddy.user_id == current_user.id) | (UserBuddy.buddy_id == current_user.id),
        UserBuddy.accepted == True
    ).all()

    print("Fetched Accepted Buddies: ", accepted_buddies)

    # Get actual buddy users (buddy is the relationship, so we get the User object)
    accepted_buddies_data = []
    for buddy in accepted_buddies:
        if buddy.user_id == current_user.id:
            accepted_buddies_data.append(buddy.buddy)  # If user_id matches, append buddy
        else:
            accepted_buddies_data.append(buddy.user)  # If buddy_id matches, append user

    print("Accepted Buddies Data: ", accepted_buddies_data)

    # Populate the dropdown with accepted buddies in add_trip route
    form.selected_users.choices = [
        (user.id, user.username) 
        for user in accepted_buddies_data if user.id != current_user.id
    ]

    # Fetch users for each trip, excluding the current user
    trip_buddies = {}
    for trip in trips:
        # Use trip.users to get the associated users and filter out the current user
        trip_buddies[trip.id] = [
            user.username for user in trip.users if user.id != current_user.id
        ]

    return render_template('index.html', 
                           user=current_user, 
                           trips=trips, 
                           form=form, 
                           invitations=invitations, 
                           accepted_buddies=accepted_buddies_data,
                           trip_buddies=trip_buddies)



@app.route('/add_trip', methods=['GET', 'POST'])
@login_required
def add_trip():
    form = TripForm()

    # Fetch accepted buddies
    accepted_buddies = UserBuddy.query.filter(
        (UserBuddy.user_id == current_user.id) | (UserBuddy.buddy_id == current_user.id),
        UserBuddy.accepted == True
    ).all()

    # Prepare a list of accepted buddies
    accepted_buddies_data = []
    for buddy in accepted_buddies:
        if buddy.user_id == current_user.id:
            if buddy.buddy.id != current_user.id:
                accepted_buddies_data.append(buddy.buddy)
        else:
            if buddy.user.id != current_user.id:
                accepted_buddies_data.append(buddy.user)

    # Remove duplicates
    accepted_buddies_data = list(set(accepted_buddies_data))

    # Populate the dropdown
    form.selected_users.choices = [
        (user.id, user.username) for user in accepted_buddies_data
    ]

    if form.validate_on_submit():
        try:
            # Create a new trip
            new_trip = Trip(
                name=form.trip_name.data,
                start_location=form.start_location.data,
                end_location=form.end_location.data,
                start_date=form.start_date.data,
                end_date=form.end_date.data,
                num_days=(form.end_date.data - form.start_date.data).days + 1,
                users=[current_user]
            )

            # Add selected users to the trip
            selected_user_ids = [int(user_id) for user_id in form.selected_users.data]
            selected_users = User.query.filter(User.id.in_(selected_user_ids)).all()
            new_trip.users.extend(selected_users)

            db.session.add(new_trip)
            db.session.commit()
            flash("Trip added successfully!", "success")

            # Redirect to index after saving
            return redirect(url_for('index'))  # Ensures redirection to index
        except Exception as e:
            db.session.rollback()
            flash(f"Error adding trip: {e}", "danger")

    elif form.errors:
        app.logger.debug(f"Form validation errors: {form.errors}")

    return render_template('index.html', form=form)



@app.route('/edit_trip/<int:trip_id>', methods=['GET', 'POST'])
@login_required
def edit_trip(trip_id):
    trip = Trip.query.get_or_404(trip_id)

    # Ensure only authorized users can edit the trip
    if current_user not in trip.users:
        flash("You are not authorized to edit this trip.", "danger")
        return redirect(url_for('index'))

    form = TripForm()

    # Fetch accepted buddies
    accepted_buddies = UserBuddy.query.filter(
        (UserBuddy.user_id == current_user.id) | (UserBuddy.buddy_id == current_user.id),
        UserBuddy.accepted == True
    ).all()

    # Prepare a list of accepted buddies
    accepted_buddies_data = []
    for buddy in accepted_buddies:
        if buddy.user_id == current_user.id:
            if buddy.buddy.id != current_user.id:
                accepted_buddies_data.append(buddy.buddy)
        else:
            if buddy.user.id != current_user.id:
                accepted_buddies_data.append(buddy.user)

    # Remove duplicates
    accepted_buddies_data = list(set(accepted_buddies_data))

    # Populate the dropdown
    form.selected_users.choices = [
        (user.id, user.username) for user in accepted_buddies_data
    ]

    # Pre-select users already in the trip
    if request.method == 'GET':
        form.trip_name.data = trip.name
        form.start_location.data = trip.start_location
        form.end_location.data = trip.end_location
        form.start_date.data = trip.start_date
        form.end_date.data = trip.end_date
        form.selected_users.data = [str(user.id) for user in trip.users if user != current_user]

    if form.validate_on_submit():
        try:
            trip.name = form.trip_name.data
            trip.start_location = form.start_location.data
            trip.end_location = form.end_location.data
            trip.start_date = form.start_date.data
            trip.end_date = form.end_date.data
            trip.num_days = (form.end_date.data - form.start_date.data).days + 1

            # Update the trip users
            selected_user_ids = [int(user_id) for user_id in form.selected_users.data]
            selected_users = User.query.filter(User.id.in_(selected_user_ids)).all()

            # Include current user in the trip users
            trip.users = [current_user] + selected_users

            db.session.commit()
            flash("Trip updated successfully!", "success")

            # Redirect to index after saving
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()
            flash(f"Error updating trip: {e}", "danger")

    elif form.errors:
        app.logger.debug(f"Form validation errors: {form.errors}")

    return render_template('edit_trip.html', form=form, trip=trip)




@app.route('/delete_trip', methods=['POST'])
@login_required
def delete_trip():
    trip_id = request.form.get('trip_id')
    try:
        trip = Trip.query.get(trip_id)
        if trip:
            db.session.delete(trip)
            db.session.commit()
            flash("Trip deleted successfully!", "success")
        else:
            flash("Trip not found!", "danger")
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting trip: {e}", "danger")
    return redirect(url_for('index'))


from flask_login import current_user

@app.route('/trip/<int:trip_id>', methods=['GET', 'POST'])
@login_required
def trip_details(trip_id):
    # Get the trip object (404 if not found)
    user = current_user
    trip = Trip.query.get_or_404(trip_id)
    # Calculate dates for each day
    days_with_dates = [
        (day, trip.start_date + timedelta(days=day - 1))
        for day in range(1, trip.num_days + 1)
    ]

    # Initialize the forms
    form = ActivityForm()
    expense_form = ExpenseForm()  # Form for adding expenses
    blog_form = BlogForm()
    
    # Extract trip dates from the days_with_dates list
    trip_dates = [date for _, date in days_with_dates]
    today = datetime.now().date()

    # Check if today is in the range of trip dates
    show_jump_to_today = min(trip_dates) <= today <= max(trip_dates)

    # Handle form submissions (activities, hotels, and expenses)
    if request.method == 'POST':
        # Handle Activity Form
        if 'activity' in request.form and form.validate_on_submit():
            day = form.day.data
            description = form.activity.data

            # Check if the day is valid
            if not (1 <= day <= trip.num_days):
                flash(f"Invalid day selected. Please choose a day between 1 and {trip.num_days}.", 'danger')
                return redirect(url_for('trip_details', trip_id=trip_id))

            # Create and save the activity
            activity = TripActivity(trip_id=trip.id, day=day, description=description)
            db.session.add(activity)
            db.session.commit()

            flash('Activity added successfully!', 'success')
            return redirect(url_for('trip_details', trip_id=trip_id))

        # Handle Hotel Form
        elif 'name' in request.form:
            try:
                name = request.form['name']
                address = request.form['address']
                from_day = int(request.form['from_day'])
                to_day = int(request.form['to_day'])

                # Check if the hotel days are valid
                if from_day > to_day or from_day < 1 or to_day > trip.num_days:
                    flash('Invalid day range for hotel. Please check your input.', 'danger')
                    return redirect(url_for('trip_details', trip_id=trip_id))

                # Remove overlapping hotels (if any)
                overlapping_hotels = Hotel.query.filter(
                    Hotel.trip_id == trip_id,
                    Hotel.from_day <= to_day,
                    Hotel.to_day >= from_day
                ).all()

                if overlapping_hotels:
                    for hotel in overlapping_hotels:
                        db.session.delete(hotel)

                # Create and save the new hotel
                new_hotel = Hotel(
                    trip_id=trip.id,
                    name=name,
                    address=address,
                    from_day=from_day,
                    to_day=to_day
                )
                db.session.add(new_hotel)
                db.session.commit()

                flash('Hotel saved successfully!', 'success')
            except ValueError as e:
                flash('Error saving hotel. Please ensure all fields are valid.', 'danger')

            return redirect(url_for('trip_details', trip_id=trip_id))

    # Fetch activities grouped by day
    activities = TripActivity.query.filter_by(trip_id=trip_id).all()
    activities_by_day = {}
    for activity in activities:
        activities_by_day.setdefault(activity.day, []).append(activity)

    # Fetch hotels grouped by day with serialized data
    hotels = Hotel.query.filter_by(trip_id=trip_id).all()
    hotels_by_day = {}
    for hotel in hotels:
        for day in range(hotel.from_day, hotel.to_day + 1):
            hotels_by_day.setdefault(day, []).append({
                'id': hotel.id,  # Add unique ID for each hotel
                'name': hotel.name,
                'address': hotel.address,
                'from_day': hotel.from_day,
                'to_day': hotel.to_day
            })

    # Fetch all expenses for the current trip
    expenses = Expense.query.filter_by(trip_id=trip.id).all()

    # Calculate the total expenses for the trip
    total_expense = round(sum(expense.amount for expense in expenses), 2)

    # Calculate the number of users in the trip
    num_users = len(trip.users.all())

    # Calculate the share each user should have paid
    average_payment = round(total_expense / num_users, 2) if num_users > 0 else 0

    # Calculate the total expenses per user
    user_expenses = db.session.query(
        Expense.user_id, db.func.sum(Expense.amount).label('total_amount')
    ).filter_by(trip_id=trip.id).group_by(Expense.user_id).all()

    # Create a dictionary of total expenses per user
    user_expenses_dict = {user_id: round(total_amount, 2) for user_id, total_amount in user_expenses}

    # Calculate balances (positive = overpaid, negative = underpaid)
    balances = {}

    # Create a dictionary for users
    users_dict = {user.id: user for user in trip.users}

    # Calculate the balance for each user (how much they owe or are owed)
    for user in trip.users:
        total_paid = user_expenses_dict.get(user.id, 0)
        balance = round(total_paid - average_payment, 2)
        balances[user.id] = balance

    # Separate users into overpaid and underpaid lists
    overpaid_users = []
    underpaid_users = []

    for user_id, balance in balances.items():
        if balance > 0:
            overpaid_users.append((user_id, balance))  # User who overpaid
        elif balance < 0:
            underpaid_users.append((user_id, abs(balance)))  # User who underpaid

    # Prepare the "Who Owes Who" summary
    owe_summary = []
    remaining_overpaid_users = []

    for overpaid_user_id, overpaid_amount in overpaid_users:
        if overpaid_amount > 0:
            remaining_overpaid_users.append((overpaid_user_id, overpaid_amount))

        # Keep track of the remaining overpaid balances
        # Copy of remaining overpaid users to ensure we don't modify it during the iteration
        # Copy of remaining overpaid users to avoid modifying it during the iteration
    remaining_overpaid_users_dict = {overpaid_user_id: overpaid_amount for overpaid_user_id, overpaid_amount in remaining_overpaid_users}

        # Processing underpaid and overpaid users
    for underpaid_user_id, underpaid_amount in underpaid_users:
        if underpaid_amount <= 0:  # Skip if no debt remaining
            continue
        
        for overpaid_user_id, overpaid_amount in list(remaining_overpaid_users_dict.items()):
            if underpaid_amount <= 0:  # Stop when all debt is paid off
                break
            
            if overpaid_amount > 0:  # Only match if there's an overpaid amount left
                amount_to_pay = min(underpaid_amount, overpaid_amount)
                
                # Add to the owe summary
                owe_summary.append({
                    'underpaid_user': users_dict.get(underpaid_user_id),
                    'overpaid_user': users_dict.get(overpaid_user_id),
                    'amount': amount_to_pay
                })
                
                # Reduce both underpaid and overpaid amounts
                underpaid_amount -= amount_to_pay
                overpaid_amount -= amount_to_pay

                # Update the remaining overpaid balance
                if overpaid_amount > 0:
                    remaining_overpaid_users_dict[overpaid_user_id] = overpaid_amount
                else:
                    del remaining_overpaid_users_dict[overpaid_user_id]  # Remove if no balance left

        # Handle any remaining underpaid amounts (if any balance is left)
        if underpaid_amount > 0:
            for overpaid_user_id, overpaid_amount in list(remaining_overpaid_users_dict.items()):
                if underpaid_amount <= 0:  # Stop if underpaid amount is fully matched
                    break

                if overpaid_amount > 0:
                    amount_to_pay = min(underpaid_amount, overpaid_amount)
                    owe_summary.append({
                        'underpaid_user': users_dict.get(underpaid_user_id),
                        'overpaid_user': users_dict.get(overpaid_user_id),
                        'amount': amount_to_pay
                    })
                    underpaid_amount -= amount_to_pay
                    overpaid_amount -= amount_to_pay

                    # Update the remaining overpaid balance
                    if overpaid_amount > 0:
                        remaining_overpaid_users_dict[overpaid_user_id] = overpaid_amount
                    else:
                        del remaining_overpaid_users_dict[overpaid_user_id]

    # Process any remaining overpaid amounts
    for overpaid_user_id, overpaid_amount in remaining_overpaid_users_dict.items():
        if overpaid_amount > 0:
            owe_summary.append({
                'underpaid_user': None,  # No one owes this residual amount
                'overpaid_user': users_dict.get(overpaid_user_id),
                'amount': overpaid_amount
            })





    # Fetch blogs for each day, grouped by day and user
    blogs_by_day_and_user = {}
    # Fetch blogs with the associated user (eager loading)
    blogs = TripBlog.query.filter_by(trip_id=trip_id).join(User).all()
    for blog in blogs:
        # Group blogs first by day, then by user
        if blog.day not in blogs_by_day_and_user:
            blogs_by_day_and_user[blog.day] = {}
        if blog.user_id not in blogs_by_day_and_user[blog.day]:
            blogs_by_day_and_user[blog.day][blog.user_id] = []
        blogs_by_day_and_user[blog.day][blog.user_id].append(blog)

    print(owe_summary)
    print(remaining_overpaid_users)
    # Render the template with activities, hotels, expenses, and forms
    return render_template(
        'trip_details.html',
        trip=trip,
        activities_by_day=activities_by_day,
        hotels_by_day=hotels_by_day,
        blogs_by_day_and_user=blogs_by_day_and_user,
        form=form,
        expense_form=expense_form,
        blog_form=blog_form,
        user=user,
        expenses=expenses,
        total_expense=total_expense,
        user_expenses_dict=user_expenses_dict,
        average_payment=average_payment,
        owe_summary=owe_summary,
        remaining_overpaid_users=remaining_overpaid_users,
        days_with_dates=days_with_dates,
        show_jump_to_today=show_jump_to_today
    )






@app.route('/trip/<int:trip_id>/add_activity', methods=['POST'])
@login_required
def add_activity(trip_id):
    # Fetch the trip
    trip = Trip.query.get_or_404(trip_id)

    # Get form data
    day = int(request.form.get('day'))
    description = request.form.get('activity')
    from_location = request.form.get('from_location')  # From location
    to_location = request.form.get('to_location')  # To location
    activity_type = request.form.get('type')

    # Create a new activity
    activity = TripActivity(
        trip_id=trip.id,
        day=day,
        description=description,
        location=to_location,  # Save the "to location" in the location field
        fromLocation=from_location,  # Save the "from location"
        type=activity_type,
        user_id=current_user.id  # Add the current user's ID
    )

    # Add and commit the new activity
    db.session.add(activity)
    db.session.commit()

    flash('Activity added successfully.', 'success')
    return redirect(url_for('trip_details', trip_id=trip_id))



@app.route('/activity/<int:activity_id>/delete', methods=['POST'])
@login_required
def delete_activity(activity_id):
    activity = TripActivity.query.get_or_404(activity_id)
    db.session.delete(activity)
    db.session.commit()
    flash('Activity deleted successfully.', 'success')
    return redirect(request.referrer or url_for('trip_details', trip_id=activity.trip_id))

@app.route('/activity/edit', methods=['POST'])
@login_required
def edit_activity():
    # Get form data
    activity_id = request.form.get('activity_id')
    description = request.form.get('description')
    day = request.form.get('day')
    location = request.form.get('location')  # Get the to location field
    from_location = request.form.get('from_location')  # Get the from location field

    # Fetch the activity
    activity = TripActivity.query.get_or_404(activity_id)

    # Update fields
    activity.description = description
    activity.day = int(day)
    activity.location = location  # Update location (can be None)
    activity.fromLocation = from_location  # Update from location

    # Commit changes
    db.session.commit()

    flash('Activity updated successfully.', 'success')
    return redirect(url_for('trip_details', trip_id=activity.trip_id))

@app.route('/trip/<int:trip_id>/hotel', methods=['POST'])
@login_required
def add_or_edit_hotel(trip_id):
    trip = Trip.query.get_or_404(trip_id)

    name = request.form.get('name')
    address = request.form.get('address')
    from_day = int(request.form.get('from_day'))
    to_day = int(request.form.get('to_day'))

    # Get the hotel ID from the form if available (for updates)
    hotel_id = request.form.get('hotel_id')

    if hotel_id:
        # If a hotel ID is provided, fetch the specific hotel for update
        hotel = Hotel.query.get(hotel_id)

        if hotel:
            # Check for overlapping hotels, excluding the current one
            overlapping_hotel = Hotel.query.filter(
                Hotel.trip_id == trip_id,
                Hotel.id != hotel.id,  # Exclude the current hotel
                (Hotel.from_day < to_day) & (Hotel.to_day > from_day)  # Overlap logic, excludes exact boundary matches
            ).first()

            if overlapping_hotel:
                flash('There is already a hotel with overlapping dates.', 'danger')
                return redirect(url_for('trip_details', trip_id=trip_id))

            # Update the hotel details
            hotel.name = name
            hotel.address = address
            hotel.from_day = from_day
            hotel.to_day = to_day
        else:
            flash('Hotel not found for updating.', 'danger')
            return redirect(url_for('trip_details', trip_id=trip_id))
    else:
        # Add a new hotel
        overlapping_hotel = Hotel.query.filter(
            Hotel.trip_id == trip_id,
            (Hotel.from_day < to_day) & (Hotel.to_day > from_day)  # Overlap logic, excludes exact boundary matches
        ).first()

        if overlapping_hotel:
            flash('There is already a hotel with overlapping dates.', 'danger')
            return redirect(url_for('trip_details', trip_id=trip_id))

        hotel = Hotel(
            trip_id=trip_id,
            name=name,
            address=address,
            from_day=from_day,
            to_day=to_day,
        )
        db.session.add(hotel)

    db.session.commit()

    flash('Hotel information saved successfully.', 'success')
    return redirect(url_for('trip_details', trip_id=trip_id))








@app.route('/trip/<int:trip_id>/hotel/delete', methods=['POST'])
@login_required
def delete_hotel(trip_id):
    trip = Trip.query.get_or_404(trip_id)

    # Parse JSON data from the request
    data = request.get_json()

    # Debugging: Print the received data
    print("Request Data Received:", data)

    # Validate and fetch the hotel name
    hotel_name = data.get('name')
    print("Hotel Name Received:", hotel_name)  # Debugging

    if not hotel_name:
        flash('Hotel name is required to delete.', 'danger')
        return jsonify({'error': 'Hotel name is required'}), 400

    # Find the hotel record that matches the trip_id and name
    hotel = Hotel.query.filter_by(trip_id=trip_id, name=hotel_name).first()

    if hotel:
        db.session.delete(hotel)
        db.session.commit()
        flash('Hotel deleted successfully.', 'success')
        return jsonify({'success': 'Hotel deleted successfully.'}), 200
    else:
        flash('Hotel not found.', 'danger')
        return jsonify({'error': 'Hotel not found.'}), 404



@app.route('/trip/<int:trip_id>/day/<int:day>/add_blog', methods=['GET', 'POST'])
@login_required
def add_blog(trip_id, day):
    # Get the trip object (404 if not found)
    trip = Trip.query.get_or_404(trip_id)
    
    # Check if the day is valid for the trip
    if not (1 <= day <= trip.num_days):
        flash(f"Invalid day selected. Please choose a day between 1 and {trip.num_days}.", 'danger')
        return redirect(url_for('trip_details', trip_id=trip_id))

    # Handle blog submission
    if request.method == 'POST':
        blog_content = request.form['blog_content']  # Ensure this matches the name in your form

        # Check if a blog already exists for this user on this day
        existing_blog = TripBlog.query.filter_by(trip_id=trip_id, user_id=current_user.id, day=day).first()
        if existing_blog:
            flash("You have already written a blog for this day.", 'danger')
            return redirect(url_for('trip_details', trip_id=trip_id))

        # Create and save the new blog entry
        new_blog = TripBlog(trip_id=trip_id, user_id=current_user.id, day=day, blog_content=blog_content)
        db.session.add(new_blog)
        db.session.commit()

        flash('Blog added successfully!', 'success')
        return redirect(url_for('trip_details', trip_id=trip_id))

    # Render the template with trip and day context
    return render_template('add_blog.html', trip=trip, day=day)

@app.route('/trip/<int:trip_id>/delete_blog/<int:blog_id>', methods=['POST'])
@login_required
def delete_blog(trip_id, blog_id):
    blog = TripBlog.query.get_or_404(blog_id)  # This gets the blog by its ID

    # Check if the current user is the one who wrote the blog
    if blog.user_id != current_user.id:
        flash('You can only delete your own blogs!', 'danger')
        return redirect(url_for('trip_details', trip_id=trip_id))

    # Delete the blog
    db.session.delete(blog)
    db.session.commit()

    flash('Blog deleted successfully!', 'success')
    return redirect(url_for('trip_details', trip_id=trip_id))



@app.route('/trip/<int:trip_id>/day/<int:day>/blog/<int:blog_id>', methods=['GET', 'POST'])
@login_required
def view_or_edit_blog(trip_id, day, blog_id):
    blog = TripBlog.query.filter_by(id=blog_id, user_id=current_user.id).first_or_404()

    # Initialize form for editing the blog
    form = BlogForm(obj=blog)

    if request.method == 'POST' and form.validate_on_submit():
        # Update the blog content if the form is valid
        blog.blog_content = form.blog_content.data
        db.session.commit()
        flash('Blog updated successfully!', 'success')
        return redirect(url_for('trip_details', trip_id=trip_id))

    # Render the template for viewing or editing the blog
    return render_template('view_or_edit_blog.html', blog=blog, form=form, trip_id=trip_id, day=day)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            if not user.email_confirmed:
                flash('Please confirm your email address before logging in.', 'warning')
                return redirect(url_for('unconfirmed'))

            # Generate and send OTP
            otp = user.generate_otp()
            send_otp_email(user.email, otp)

            # Store user ID and remember value in the session
            session['user_id'] = user.id
            session['remember'] = form.remember.data

            flash('A one-time password has been sent to your email.', 'info')
            return redirect(url_for('verify_otp'))
        else:
            flash('Invalid email or password.', 'danger')
    return render_template('login.html', form=form)


@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    form = OTPForm()
    user_id = session.get('user_id')
    remember = session.get('remember', False)

    # Check if user_id exists in the session
    if not user_id:
        flash('Session expired. Please log in again.', 'danger')
        return redirect(url_for('login'))

    # Retrieve user from the database
    user = User.query.get(user_id)

    if form.validate_on_submit():
        if user and user.verify_otp(form.otp.data):
            login_user(user, remember=remember)  # Use remember value from the session
            user.clear_otp()  # Clear the OTP after successful login
            session.pop('user_id', None)  # Remove user ID from the session
            session.pop('remember', None)  # Remove remember value from the session
            flash('Logged in successfully.', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid or expired OTP.', 'danger')
    return render_template('verify_otp.html', form=form)


@app.route('/trip/<int:trip_id>/add_expense', methods=['GET', 'POST'])
@login_required
def add_expense(trip_id):
    # Get the trip object (404 if not found)
    trip = Trip.query.get_or_404(trip_id)

    # Handle expense form submission logic
    expense_form = ExpenseForm()

    # Set user_id and user_display programmatically
    expense_form.user_id.data = current_user.id  # Automatically set the user_id
    expense_form.user_display.data = current_user.username  # Display the username in the form (readonly)

    # Debugging: Check the form data and request method
    print(f"Form Data - Amount: {expense_form.amount.data}, Description: {expense_form.description.data}")
    print(f"Form method: {request.method}")
    print(f"Is user authenticated? {current_user.is_authenticated}")
    print(f"User ID from current_user: {current_user.id}")
    
    if expense_form.validate_on_submit():
        amount = expense_form.amount.data
        description = expense_form.description.data
        user_id = expense_form.user_id.data  # This will use the hidden user_id field

        print(f"User ID from form: {user_id}")
        print(f"User display from form: {expense_form.user_display.data}")

        # Create the expense object
        expense = Expense(trip_id=trip.id, user_id=user_id, amount=amount, description=description)

        # Add expense to the database
        print(f"Adding Expense to DB - Trip ID: {trip.id}, User ID: {user_id}, Amount: {amount}, Description: {description}")
        db.session.add(expense)
        db.session.commit()

        print(f"Expense added successfully with ID: {expense.id}")

        
        return redirect(url_for('trip_details', trip_id=trip_id) + "#expensesSection")


    return redirect(url_for('trip_details', trip_id=trip_id) + "#expensesSection")





@app.route('/invite_to_be_travel_buddy', methods=['POST'])
@login_required
def invite_to_be_travel_buddy():
    email = request.form['email']
    invited_user = User.query.filter_by(email=email).first()

    if invited_user:
        existing_buddy = UserBuddy.query.filter(
            (UserBuddy.user_id == current_user.id) & (UserBuddy.buddy_id == invited_user.id)
        ).first()

        if existing_buddy:
            flash(f'{invited_user.username} is already your travel buddy.', 'info')
        else:
            new_buddy = UserBuddy(user_id=current_user.id, buddy_id=invited_user.id)
            db.session.add(new_buddy)
            db.session.commit()
            flash(f'Invitation sent to {invited_user.username}!', 'success')
    else:
        flash(f'User with email {email} not found.', 'danger')

    return redirect(url_for('index'))  # Redirect to the index (home) page


@app.route('/accept_buddy_invitation/<int:buddy_id>', methods=['POST'])
@login_required
def accept_buddy_invitation(buddy_id):
    buddy_relation = UserBuddy.query.filter_by(user_id=buddy_id, buddy_id=current_user.id).first()
    
    if buddy_relation and not buddy_relation.accepted:
        buddy_relation.accepted = True
        db.session.commit()
        flash('You have accepted the buddy invitation!', 'success')
    else:
        flash('Invalid invitation or already accepted.', 'danger')
    
    return redirect(url_for('index'))  # Redirect to the index (home) page


@app.route('/remove_buddy/<int:buddy_id>', methods=['POST'])
@login_required
def remove_buddy(buddy_id):
    # Find the buddy relationship where current_user is the buddy of the given user
    buddy_relation = UserBuddy.query.filter_by(user_id=buddy_id, buddy_id=current_user.id).first()

    if buddy_relation:
        db.session.delete(buddy_relation)
        db.session.commit()
        flash('You have removed the travel buddy!', 'success')
    else:
        flash('No such travel buddy found or you are not connected.', 'danger')

    return redirect(url_for('index'))


@app.route('/trip/<int:trip_id>/delete_expense/<int:expense_id>', methods=['POST'])
@login_required
def delete_expense(trip_id, expense_id):
    # Get the trip object (404 if not found)
    trip = Trip.query.get_or_404(trip_id)
    
    # Get the expense object (404 if not found)
    expense = Expense.query.get_or_404(expense_id)
    
    # Ensure the current logged-in user is allowed to delete this expense (for example, check if the user is the one who added the expense)
    if expense.user_id != current_user.id and not current_user.is_admin:
        abort(403)  # Forbidden if the user is not the one who added the expense

    # Delete the expense from the database
    db.session.delete(expense)
    db.session.commit()

    # Redirect to the trip details page after deletion
    return redirect(url_for('trip_details', trip_id=trip.id) + "#expensesSection")


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))



@app.route('/resend')
@login_required
def resend_confirmation():
    send_confirmation_email(current_user.email)
    flash('A new confirmation email has been sent.', 'success')
    return redirect(url_for('unconfirmed'))
